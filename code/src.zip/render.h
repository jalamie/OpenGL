//----------------------------------------------------------------------------------------
/**
 * \file    render.h
 * \author  Jamie Goh
 * \date    2023
 * \brief   Rendering stuff - drawing functions for models, etc.
 */
 //----------------------------------------------------------------------------------------

#ifndef __RENDER_H
#define __RENDER_H

#include "data.h"

// defines geometry of object in the scene (space ship, plane, walls, etc.)
// geometry is shared among all instances of the same object type
typedef struct _MeshGeometry {
	GLuint        vertexBufferObject;   // identifier for the vertex buffer object
	GLuint        elementBufferObject;  // identifier for the element buffer object
	GLuint        vertexArrayObject;    // identifier for the vertex array object
	unsigned int  numTriangles;         // number of triangles in the mesh
	// material
	glm::vec3     ambient;
	glm::vec3     diffuse;
	glm::vec3     specular;
	float         shininess;
	GLuint        texture;

} MeshGeometry;

// parameters of individual objects in the scene (e.g. position, size, speed, etc.)
typedef struct _Object {
	glm::vec3 position;
	glm::vec3 temp_position;
	glm::vec3 direction;
	float     speed;
	float     size;

	bool destroyed;

	float startTime;
	float currentTime;

} Object;

typedef struct _SharkObject : public Object {

	float viewAngle; // in degrees

} SharkObject;

typedef struct _WallObject : public Object {

	float rotationSpeed;

} WallObject;

typedef struct MushroomObject : public Object {

} MushroomObject;

typedef struct TerrainObject : public Object {

} TerrainObject;

typedef struct SantaObject : public Object {
	glm::vec3 initPosition;

} SantaObject;

typedef struct SnowmanObject : public Object {

} SnowmanObject;

typedef struct YoshiObject : public Object {

} YoshiObject;

typedef struct GingerbreadmanObject : public Object {

} GingerbreadmanObject;

typedef struct ChickenObject : public Object {

} ChickenObject;

typedef struct DittoObject : public Object {

} DittoObject;

typedef struct PlaneObject : public Object {

	float angle;

} PlaneObject;


typedef struct ConeObject : public Object {


} ConeObject;

typedef struct _ExplosionObject : public Object {

  int    textureFrames;
  float  frameDuration;

} ExplosionObject;

typedef struct _BannerObject : public Object {

} BannerObject;

typedef struct _commonShaderProgram {
	// identifier for the shader program
	GLuint program;          // = 0;
	// vertex attributes locations
	GLint posLocation;       // = -1;
	GLint colorLocation;     // = -1;
	GLint normalLocation;    // = -1;
	GLint texCoordLocation;  // = -1;
	// uniforms locations
	GLint PVMmatrixLocation;    // = -1;
	GLint VmatrixLocation;      // = -1;  view/camera matrix
	GLint MmatrixLocation;      // = -1;  modeling matrix
	GLint normalMatrixLocation; // = -1;  inverse transposed Mmatrix

	GLint timeLocation;         // = -1; elapsed time in seconds
	 //fog
	GLint fogOnLoc_linear;
	GLint fogOnLoc_near;
	GLint fogOnLoc_density;
	GLint fogOnLoc_exp;

	//animate
	GLint animateLoc;
                                                                                                                                  
	//pointlight
	GLint pointLoc;

	// material 
	GLint diffuseLocation;    // = -1;
	GLint ambientLocation;    // = -1;
	GLint specularLocation;   // = -1;
	GLint shininessLocation;  // = -1;
	// texture
	GLint useTextureLocation; // = -1; 
	GLint texSamplerLocation; // = -1;
	// reflector related uniforms
	GLint reflectorPositionLocation;  // = -1; 
	GLint reflectorDirectionLocation; // = -1;
} SCommonShaderProgram;

glm::vec3 checkBounds(const glm::vec3& position, float objectSize = 1.0f);

void drawMushroom(MushroomObject* mushroom, const glm::mat4& viewMatrix, const glm::mat4& projectionMatrix);
void drawTerrain(TerrainObject* terrain, const glm::mat4& viewMatrix, const glm::mat4& projectionMatrix);
void drawSanta(SantaObject* santa, const glm::mat4& viewMatrix, const glm::mat4& projectionMatrix);
void drawYoshi(YoshiObject* yoshi, const glm::mat4& viewMatrix, const glm::mat4& projectionMatrix);
void drawGingerbreadman(GingerbreadmanObject* gingerbreadman, const glm::mat4& viewMatrix, const glm::mat4& projectionMatrix);
void drawSnowman(SnowmanObject* snowman, const glm::mat4& viewMatrix, const glm::mat4& projectionMatrix);
void drawChicken(ChickenObject* chicken, const glm::mat4& viewMatrix, const glm::mat4& projectionMatrix);
void drawDitto(DittoObject* ditto, const glm::mat4& viewMatrix, const glm::mat4& projectionMatrix);
void drawPlane(PlaneObject* plane, const glm::mat4& viewMatrix, const glm::mat4& projectionMatrix);
void drawShark(SharkObject* shark, const glm::mat4& viewMatrix, const glm::mat4& projectionMatrix);
void drawWall(WallObject* wall, const glm::mat4& viewMatrix, const glm::mat4& projectionMatrix);
// void drawUfo(UfoObject* ufo, const glm::mat4& viewMatrix, const glm::mat4& projectionMatrix);
void drawCone(ConeObject* cone, const glm::mat4& viewMatrix, const glm::mat4& projectionMatrix);
void drawExplosion(ExplosionObject* explosion, const glm::mat4 & viewMatrix, const glm::mat4 & projectionMatrix);
void drawBanner(BannerObject* banner, const glm::mat4 & viewMatrix, const glm::mat4 & projectionMatrix, bool win);
void drawSkybox(const glm::mat4& viewMatrix, const glm::mat4& projectionMatrix, int day);

void initializeShaderPrograms();
void cleanupShaderPrograms();

void initializeModels();
void cleanupModels();

#endif // __RENDER_H
