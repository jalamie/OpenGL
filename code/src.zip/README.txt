Keyboard directory (only for lowercase)

Camera Viewpoints
1: change the camera to POV
2: change the camera to top view following shark
3: change to top down view of the scene

Movements
W: shark moves forward
A: shark turns left 
S: shark moves backwards
D: shark turns right 

E: for random explosions
U: to move the mouse in POV 

Arrow Up: increase fog 
Arrow Down: decrease fog
Arrow left: decrease field of view
Arrow right: increase field of view
