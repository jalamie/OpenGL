//----------------------------------------------------------------------------------------
/**
 * \file    data.h
 * \author  Jamie Goh
 * \date    2023
 * \brief   Basic defines and data structures.
 */
 //----------------------------------------------------------------------------------------

#ifndef __DATA_H
#define __DATA_H

#define WINDOW_WIDTH   750
#define WINDOW_HEIGHT  750
#define WINDOW_TITLE   "Maze Game"

#define GAME_TIME      100

// keys used in the key map
enum { KEY_LEFT_ARROW, KEY_RIGHT_ARROW, KEY_UP_ARROW, KEY_DOWN_ARROW, U, W, A, S, D, C, KEYS_COUNT };

//#define WALL_PARTS       1

#define WALL_SIZE        0.1f

#define SHARK_VIEW_ANGLE_DELTA 2.0f // in degrees
#define SHARK_SIZE   0.04f

#define BILLBOARD_SIZE   0.03f
#define BANNER_SIZE      1.0f

#define MOVEMENT     0.01f //speed of shark

#define SCENE_WIDTH  1.0f
#define SCENE_HEIGHT 1.0f
#define SCENE_DEPTH  1.0f

#define CAMERA_ELEVATION_MAX 45.0f

//additional
#define TERRAIN_SIZE         1.0f
#define MUSHROOM_SIZE        0.03f
#define YOSHI_SIZE           0.03f
#define SNOWMAN_SIZE         0.03f
#define SANTA_SIZE           0.03f
#define SANTA_SPEED          0.1f
#define GINGERBREADMAN_SIZE  0.03f
#define CHICKEN_SIZE         0.03f
#define DITTO_SIZE           0.03f
#define PLANE_SIZE           0.04f
#define CONE_SIZE            0.03f

#define UFOS_COUNT_MIN 1
#define UFOS_COUNT_MAX 3
#define UFO_SIZE         0.0f
#define UFO_ROTATION_SPEED_MAX      1.0f

// default shaders - color per vertex and matrix multiplication
const std::string colorVertexShaderSrc(
    "#version 140\n"
    "uniform mat4 PVMmatrix;\n"
    "in vec3 position;\n"
    "in vec3 color;\n"
    "smooth out vec4 theColor;\n"
    "void main() {\n"
    "  gl_Position = PVMmatrix * vec4(position, 1.0);\n"
    "  theColor = vec4(color, 1.0);\n"
    "}\n"
);

const std::string colorFragmentShaderSrc(
    "#version 140\n"
    "smooth in vec4 theColor;\n"
    "out vec4 outputColor;\n"
    "void main() {\n"
    "  outputColor = theColor;\n"
    "}\n"
);

// each vertex shader receives screen space coordinates and calculates world direction
const std::string skyboxFarPlaneVertexShaderSrc(
    "#version 140\n"
    "\n"
    "uniform mat4 inversePVmatrix;\n"
    "in vec2 screenCoord;\n"
    "out vec3 texCoord_v;\n"
    "\n"
    "void main() {\n"
    "  vec4 farplaneCoord = vec4(screenCoord, 0.9999, 1.0);\n"
    "  vec4 worldViewCoord = inversePVmatrix * farplaneCoord;\n"
    "  texCoord_v = worldViewCoord.xyz / worldViewCoord.w;\n"
    "  gl_Position = farplaneCoord;\n"
    "}\n"
);

// fragment shader uses interpolated 3D tex coords to sample cube map
const std::string skyboxFarPlaneFragmentShaderSrc(
    "#version 140\n"
    "\n"
    "uniform samplerCube skyboxSampler;\n"
    "in vec3 texCoord_v;\n"
    "out vec4 color_f;\n"
    "\n"
    "void main() {\n"
    "  color_f = texture(skyboxSampler, texCoord_v);\n"
    "}\n"
);

const int coneTrianglesCount = 33;
const float coneVertices[] = {
  0.000000, -1.000000, -1.000000, 1.0, 0.0, 0.0, 0.0878, 0.4455, -0.8910,
  0.195090, -1.000000, -0.980785, 1.0, 0.3, 0.0, 0.2599, 0.4455, -0.8567,
  0.382683, -1.000000, -0.923880, 1.0, 0.6, 0.0, 0.4220, 0.4455, -0.7896,
  0.555570, -1.000000, -0.831470, 1.0, 1.0, 0.0, 0.5680, 0.4455, -0.6921,
  0.707107, -1.000000, -0.707107, 0.6, 1.0, 0.0, 0.6921, 0.4455, -0.5680,
  0.831470, -1.000000, -0.555570, 0.3, 1.0, 0.0, 0.7896, 0.4455, -0.4220,
  0.923880, -1.000000, -0.382683, 0.0, 1.0, 0.0, 0.8567, 0.4455, -0.2599,
  0.980785, -1.000000, -0.195090, 0.0, 1.0, 0.3, 0.8910, 0.4455, -0.0878,
  1.000000, -1.000000, 0.000000, 0.0, 1.0, 0.6, 0.8910, 0.4455, 0.0878,
  0.980785, -1.000000, 0.195090, 0.0, 1.0, 1.0, 0.8567, 0.4455, 0.2599,
  0.923880, -1.000000, 0.382683, 0.0, 0.6, 1.0, 0.7896, 0.4455, 0.4220,
  0.831470, -1.000000, 0.555570, 0.0, 0.3, 1.0, 0.6921, 0.4455, 0.5680,
  0.707107, -1.000000, 0.707107, 0.0, 0.0, 1.0, 0.5680, 0.4455, 0.6921,
  0.555570, -1.000000, 0.831470, 0.3, 0.0, 1.0, 0.4220, 0.4455, 0.7896,
  0.382683, -1.000000, 0.923880, 0.6, 0.0, 1.0, 0.2599, 0.4455, 0.8567,
  0.195090, -1.000000, 0.980785, 1.0, 0.0, 1.0, 0.0878, 0.4455, 0.8910,
  0.000000, -1.000000, 1.000000, 1.0, 0.0, 0.6, -0.0878, 0.4455, 0.8910,
  -0.195090, -1.000000, 0.980785, 1.0, 0.0, 0.3, -0.2599, 0.4455, 0.8567,
  -0.382683, -1.000000, 0.923880, 1.0, 0.0, 0.0, -0.4220, 0.4455, 0.7896,
  -0.555570, -1.000000, 0.831470, 1.0, 0.3, 0.0, -0.5680, 0.4455, 0.6921,
  -0.707107, -1.000000, 0.707107, 1.0, 0.6, 0.0, -0.6921, 0.4455, 0.5680,
  -0.831470, -1.000000, 0.555570, 1.0, 1.0, 0.0, -0.7896, 0.4455, 0.4220,
  -0.923880, -1.000000, 0.382683, 0.6, 1.0, 0.0, -0.8567, 0.4455, 0.2599,
  -0.980785, -1.000000, 0.195090, 0.3, 1.0, 0.0, -0.8910, 0.4455, 0.0878,
  -1.000000, -1.000000, 0.000000, 0.0, 1.0, 0.0, -0.8910, 0.4455, -0.0878,
  -0.980785, -1.000000, -0.195090, 0.0, 1.0, 0.3, -0.8567, 0.4455, -0.2599,
  -0.923880, -1.000000, -0.382683, 0.0, 1.0, 0.6, -0.7896, 0.4455, -0.4220,
  -0.831470, -1.000000, -0.555570, 0.0, 1.0, 1.0, -0.6921, 0.4455, -0.5680,
  -0.707107, -1.000000, -0.707107, 0.0, 0.6, 1.0, -0.5680, 0.4455, -0.6921,
  -0.555570, -1.000000, -0.831470, 0.0, 0.3, 1.0, -0.4220, 0.4455, -0.7896,
  -0.382683, -1.000000, -0.923880, 0.0, 0.0, 1.0, -0.0000, -1.0000, -0.0000,
  -0.195090, -1.000000, -0.980785, 0.3, 0.0, 1.0, -0.2599, 0.4455, -0.8567,
  0.000000, 1.000000, 0.000000, 0.0, 1.0, 0.0, -0.0878, 0.4455, -0.8910,

};

const unsigned int coneIndices[] = {
  0, 32, 1,
  1, 32, 2,
  2, 32, 3,
  3, 32, 4,
  4, 32, 5,
  5, 32, 6,
  6, 32, 7,
  7, 32, 8,
  8, 32, 9,
  9, 32, 10,
  10, 32, 11,
  11, 32, 12,
  12, 32, 13,
  13, 32, 14,
  14, 32, 15,
  15, 32, 16,
  16, 32, 17,
  17, 32, 18,
  18, 32, 19,
  19, 32, 20,
  20, 32, 21,
  21, 32, 22,
  22, 32, 23,
  23, 32, 24,
  24, 32, 25,
  25, 32, 26,
  26, 32, 27,
  27, 32, 28,
  28, 32, 29,
  29, 32, 30,
  30, 32, 31,
  31, 32, 0
};

const int ufoTrianglesCount = 6;
// temp constants used for ufoVertices array contents definition
const float ufoH = 0.25f;
const float cos30d = (float)cos(M_PI / 6.0);
const float sin30d = (float)sin(M_PI / 6.0);

const float ufoVertices[] = {
    // ufo is formed by two parts (top and bottom) joined together
    // each part is drawn as six separate triangles connected together

    // drawArrays() part of data (top part), interleaved array
    // vertices 0..5 are on the border, vertex 6 is in the center
    // colors of the triangles alternate between yellow (1,1,0) and magenta (1,0,1)

    // interleaved array: position/color/normal
    //  x      y        z     r     g     b             nx     ny         nz
    // triangle 5 0 6 -> yellow color
    //  cos30d, 0.0f, -sin30d,  1.0f, 1.0f, 0.0f,          ufoH, 1.0f,         0.0f, // 5
    //    0.0f, ufoH,    0.0f,  1.0f, 1.0f, 0.0f,          ufoH, 1.0f,         0.0f, // 6
    //  cos30d, 0.0f,  sin30d,  1.0f, 1.0f, 0.0f,          ufoH, 1.0f,         0.0f, // 0
    // // triangle 1 2 6 -> yellow color
    //    0.0f, 0.0f,    1.0f,  1.0f, 1.0f, 0.0f,  -ufoH * sin30d, 1.0f,  ufoH * cos30d, // 1
    //    0.0f, ufoH,    0.0f,  1.0f, 1.0f, 0.0f,  -ufoH * sin30d, 1.0f,  ufoH * cos30d, // 6
    // -cos30d, 0.0f,  sin30d,  1.0f, 1.0f, 0.0f,  -ufoH * sin30d, 1.0f,  ufoH * cos30d, // 2
    // // triangle 3 4 6 -> yellow color
    // -cos30d, 0.0f, -sin30d,  1.0f, 1.0f, 0.0f,  -ufoH * sin30d, 1.0f, -ufoH * cos30d, // 3
    //    0.0f, ufoH,    0.0f,  1.0f, 1.0f, 0.0f,  -ufoH * sin30d, 1.0f, -ufoH * cos30d, // 6
    //    0.0f, 0.0f,   -1.0f,  1.0f, 1.0f, 0.0f,  -ufoH * sin30d, 1.0f, -ufoH * cos30d, // 4

    // // triangle 0 1 6 -> magenta color
    //  cos30d, 0.0f,  sin30d,  1.0f, 0.0f, 1.0f,   ufoH * sin30d, 1.0f,  ufoH * cos30d, // 0
    //    0.0f, ufoH,    0.0f,  1.0f, 0.0f, 1.0f,   ufoH * sin30d, 1.0f,  ufoH * cos30d, // 6
    //    0.0f, 0.0f,    1.0f,  1.0f, 0.0f, 1.0f,   ufoH * sin30d, 1.0f,  ufoH * cos30d, // 1
    // // triangle 2 3 6 -> magenta color
    // -cos30d, 0.0f,  sin30d,  1.0f, 0.0f, 1.0f,         -ufoH, 1.0f,         0.0f, // 2
    //    0.0f, ufoH,    0.0f,  1.0f, 0.0f, 1.0f,         -ufoH, 1.0f,         0.0f, // 6
    // -cos30d, 0.0f, -sin30d,  1.0f, 0.0f, 1.0f,         -ufoH, 1.0f,         0.0f, // 3
    // // triangle 4 5 6 -> magenta color
    //    0.0f, 0.0f,   -1.0f,  1.0f, 0.0f, 1.0f,   ufoH * sin30d, 1.0f, -ufoH * cos30d, // 4
    //    0.0f, ufoH,    0.0f,  1.0f, 0.0f, 1.0f,   ufoH * sin30d, 1.0f, -ufoH * cos30d, // 6
    //  cos30d, 0.0f, -sin30d,  1.0f, 0.0f, 1.0f,   ufoH * sin30d, 1.0f, -ufoH * cos30d, // 5

    // draw elements data part (bottom part), interleaved array
    // vertices 0..5 are on the border, vertex 6 is in the center
    // vertices on the border have the same color while vertex in the middle differs

    //  x      y        z      r     g     b        nx      ny      nz
     cos30d,  0.0f,  sin30d,  1.0f, 0.0f, 1.0f,   ufoH * cos30d, -1.0f,  ufoH * sin30d, // 0
       0.0f,  0.0f,    1.0f,  1.0f, 0.0f, 1.0f,          0.0f, -1.0f,         1.0f, // 1
    -cos30d,  0.0f,  sin30d,  1.0f, 0.0f, 1.0f,  -ufoH * cos30d, -1.0f,  ufoH * sin30d, // 2
    -cos30d,  0.0f, -sin30d,  1.0f, 0.0f, 1.0f,  -ufoH * cos30d, -1.0f, -ufoH * sin30d, // 3
       0.0f,  0.0f,   -1.0f,  1.0f, 0.0f, 1.0f,          0.0f, -1.0f,        -1.0f, // 4
     cos30d,  0.0f, -sin30d,  1.0f, 0.0f, 1.0f,   ufoH * cos30d, -1.0f, -ufoH * sin30d, // 5
       0.0f, -ufoH,    0.0f,  0.3f, 0.3f, 0.3f,          0.0f, -1.0f,         0.0f, // 6

};

// indices of the 6 faces used to draw the bottom part of the ufo
const unsigned int ufoIndices[] = {

    // indices are shifted by 18 (18 vertices are stored before the second part vertices)
    5, 0, 6,
    0, 1, 6,
    1, 2, 6,
    2, 3, 6,
    3, 4, 6,
    4, 5, 6

};


const int explosionNumQuadVertices = 4;
const float explosionVertexData[explosionNumQuadVertices * 5] = {

// ======== BEGIN OF SOLUTION - TASK 4_2-1 ======== //
  // set the correct uv coordinates for the fire (stretch the texture over the whole billboard)
  // mapping of the texture coordinates to the current fire frame has to be done inside
  // the explosion fragment shader -> see sampleTexture(frame) function
  // x      y     z     u     v
  -1.0f, -1.0f, 0.0f, 0.0f, 0.0f,
   1.0f, -1.0f, 0.0f, 1.0f, 0.0f,
  -1.0f,  1.0f, 0.0f, 0.0f, 1.0f,
   1.0f,  1.0f, 0.0f, 1.0f, 1.0f,
// ========  END OF SOLUTION - TASK 4_2-1  ======== //
};

const int bannerNumQuadVertices = 4;
const float bannerVertexData[bannerNumQuadVertices * 5] = {

  // set the correct uv coordinates, so the "game over" image will be repeated 
  // three times in the u coordinate direction
  //  x      y     z     u     v

-1.0f, 0.15f, 0.0f, 0.0f, 1.0f,
-1.0f, -0.15f, 0.0f, 0.0f, 0.0f,
1.0f, 0.15f, 0.0f, 1.0f * 3.0f, 1.0f,
1.0f, -0.15f, 0.0f, 1.0f * 3.0f, 0.0f
};


#endif // __DATA_H
