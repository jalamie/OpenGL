//----------------------------------------------------------------------------------------
/**
 * \file    maze.cpp
 * \author  Jamie Goh
 * \date    2023
 * \brief   Simple implementaion of maze game.
 */
 //----------------------------------------------------------------------------------------

#include <time.h>
#include <list>
#include "pgr.h"
#include "render.h"
#include "spline.h"
#include "data.h"
#include "INIReader.h"
#include <unordered_map>
#include <iostream>
#include <cstdlib> // for rand and srand
#include <ctime>   // for time
#include <glm/glm.hpp>

extern SCommonShaderProgram shaderProgram;
extern bool useLighting;

typedef std::list<void*> GameObjectsList;

struct GameState {

    int windowWidth;    // set by reshape callback
    int windowHeight;   // set by reshape callback

    int CameraMode;        // false;
    float cameraElevationAngle; // in degrees = initially 0.0f

    bool gameOver;              // false;
    bool gameWon;               //false;
    bool keyMap[KEYS_COUNT];    // false

    float elapsedTime;

} gameState;

struct GameObjects {

    SharkObject* shark; // NULL

    GameObjectsList walls;

    MushroomObject* mushroom;
    TerrainObject* terrain;
    YoshiObject* yoshi;
    SnowmanObject* snowman;
    GingerbreadmanObject* gingerbreadman;
    SantaObject* santa;
    ChickenObject* chicken;
    DittoObject* ditto;
    PlaneObject* plane;

    // GameObjectsList ufos;
    ConeObject* cone;
    GameObjectsList explosions;
    BannerObject* bannerObject; // NULL;
} gameObjects;

float fieldofview = 60.0f;

int day;
bool day_flag = true;

bool fog_linear = false;
bool fog_exp = false;
bool fog_exp_flag = true; //allows fog_exp to be as true 
float fog_near = -0.7f;
float fog_density = 0.0f;

int countdown = GAME_TIME;

bool timer_countdown = false;

int shark_startpoint;

bool moving = true;

int animate = 1;

int point = 0;

bool isMouseWarped = false;

// START OF CONFIG PARSING

std::unordered_map<std::string, float> readConfig(const std::string& filename) {
    INIReader reader(filename);
    std::unordered_map<std::string, float> configValues;

    if (reader.ParseError() < 0) {
        std::cout << "Can't load " << filename << std::endl;
        return configValues; // Returns an empty map if there's an error
    }

    // Reading cat configuration
    configValues["Santa.speed"] = reader.GetReal("Santa", "speed", SANTA_SPEED);
    configValues["Santa.size"] = reader.GetReal("Santa", "size", SANTA_SIZE);

    // Reading shark configuration
    configValues["Shark.speed"] = reader.GetReal("Shark", "speed", MOVEMENT);
    configValues["Shark.size"] = reader.GetReal("Shark", "size", SHARK_SIZE);

    // Reading fern configuration
    configValues["Plane.size"] = reader.GetReal("Plane", "size", PLANE_SIZE);

    return configValues;
}

void reloadConfig() {
    // Read the configuration
    auto configValues = readConfig("config.ini");

    // Update game objects based on the new configuration
    // Similar to how you handle it in the restartGame function
    // For example, updating the cat object:
    if (gameObjects.santa != NULL) {
        gameObjects.santa->size = configValues["Santa.size"];
        gameObjects.santa->speed = configValues["Santa.speed"];
    }

    if (gameObjects.shark != NULL) {
        gameObjects.shark->size = configValues["Shark.size"];
        gameObjects.shark->speed = configValues["Shark.speed"];
    }

    if (gameObjects.plane != NULL) {
        gameObjects.plane->size = configValues["Plane.size"];
    }
}


// END OF CONFIG PARSING



int getRandomNumber() {
    // Seed the random number generator with the current time
    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    // Generate a random number in the range [0, 3]
    int randomNumber = std::rand() % 4;

    return randomNumber;
}

void sharkstartpoint(int start) {

    switch (start) {
    case 0: //top right
        gameObjects.shark->position = glm::vec3(0.9f, 0.6f, 0.01f);
        gameObjects.shark->temp_position = glm::vec3(0.9f, 0.6f, 0.01f);
        gameObjects.shark->viewAngle = 180.0f;
        break;
    case 1: //bottom middle
        gameObjects.shark->position = glm::vec3(0.1f, -0.95f, 0.01f);
        gameObjects.shark->temp_position = glm::vec3(0.1f, -0.95f, 0.01f);
        gameObjects.shark->viewAngle = 90.0f;
        break;
    case 2: //top left
        gameObjects.shark->position = glm::vec3(-0.9f, 0.6f, 0.01f);
        gameObjects.shark->temp_position = glm::vec3(-0.9f, 0.6f, 0.01f);
        gameObjects.shark->viewAngle = 0.0f;
        break;
    case 3: //top middle
        gameObjects.shark->position = glm::vec3(-0.3f, 0.95f, 0.01f);
        gameObjects.shark->temp_position = glm::vec3(-0.3f, 0.95f, 0.01f);
        gameObjects.shark->viewAngle = 270.0f;
        break;
    }
}

bool pointInCube(const glm::vec3& point, const glm::vec3& cubeCenter) {
    float halfSize = WALL_SIZE + SHARK_SIZE;
    return (
        point.x >= cubeCenter.x - halfSize && point.x <= cubeCenter.x + halfSize &&
        point.y >= cubeCenter.y - halfSize && point.y <= cubeCenter.y + halfSize &&
        point.z >= cubeCenter.z - halfSize && point.z <= cubeCenter.z + halfSize
        );
}

bool checkcollision(void) {
    for (GameObjectsList::iterator itA = gameObjects.walls.begin(); itA != gameObjects.walls.end(); ++itA) {
        WallObject* wall = (WallObject*)(*itA);

        if (pointInCube(gameObjects.shark->temp_position, wall->position) == true) {
            std::cout << "Collision Detected!" << std::endl;
            return true;

        }
    }
    //printf("no collision");
    return false;
}

void insertExplosion(const glm::vec3 &position, float size) {

  ExplosionObject* newExplosion = new ExplosionObject;

  newExplosion->speed = 0.0f;
  newExplosion->destroyed = false;

  newExplosion->startTime = gameState.elapsedTime;
  newExplosion->currentTime = newExplosion->startTime;

  newExplosion->size = size;
  newExplosion->direction = glm::vec3(0.0f, 0.0f, 1.0f);

  newExplosion->frameDuration = 0.1f;
  newExplosion->textureFrames = 16;

  newExplosion->position = position;

  gameObjects.explosions.push_back(newExplosion);
}

void moveSharkForward(void) {

    gameObjects.shark->temp_position += gameObjects.shark->speed * gameObjects.shark->direction;
    gameObjects.shark->temp_position = checkBounds(gameObjects.shark->temp_position, gameObjects.shark->size);
    if (checkcollision() == false) {
        gameObjects.shark->position = gameObjects.shark->temp_position;
    }
    else {
        gameObjects.shark->temp_position = gameObjects.shark->position;
    }
}

void moveSharkBackward(void) {

    gameObjects.shark->temp_position -= gameObjects.shark->speed * gameObjects.shark->direction;
    gameObjects.shark->temp_position = checkBounds(gameObjects.shark->temp_position, gameObjects.shark->size);
    if (checkcollision() == false) {
        gameObjects.shark->position = gameObjects.shark->temp_position;
    }
    else {
        gameObjects.shark->temp_position = gameObjects.shark->position;
    }
}

void turnSharkLeft(float deltaAngle) {

    gameObjects.shark->viewAngle += deltaAngle;

    if (gameObjects.shark->viewAngle > 360.0f)
        gameObjects.shark->viewAngle -= 360.0f;

    float angle = glm::radians(gameObjects.shark->viewAngle);

    gameObjects.shark->direction.x = cos(angle);
    gameObjects.shark->direction.y = sin(angle);
}

void turnSharkRight(float deltaAngle) {

    gameObjects.shark->viewAngle -= deltaAngle;

    if (gameObjects.shark->viewAngle < 0.0f)
        gameObjects.shark->viewAngle += 360.0f;

    float angle = glm::radians(gameObjects.shark->viewAngle);

    gameObjects.shark->direction.x = cos(angle);
    gameObjects.shark->direction.y = sin(angle);
}

void cleanUpObjects(void) {

    // delete wall
    while (!gameObjects.walls.empty()) {
        delete gameObjects.walls.back();
        gameObjects.walls.pop_back();
    }

    // delete explosions
    while(!gameObjects.explosions.empty()) {
    delete gameObjects.explosions.back();
    gameObjects.explosions.pop_back();
    } 

    //remove banner
    if (gameObjects.bannerObject != NULL) {
        delete gameObjects.bannerObject;
        gameObjects.bannerObject = NULL;
    }

}

WallObject* createWall(float x, float y) {
    WallObject* newWall = new WallObject;

    newWall->startTime = gameState.elapsedTime;
    newWall->currentTime = newWall->startTime;

    newWall->size = WALL_SIZE;

    // generate motion direction randomly in range -1.0f ... 1.0f
    newWall->direction = glm::vec3(
        (float)(0.0),
        (float)(0.0),
        0.0f
    );

    newWall->position = glm::vec3(x, y, 0.0f);
    newWall->temp_position = glm::vec3(x, y, 0.0f);

    // motion speed 0.0f ... 1.0f
    //newWall->speed = 0.0f;

    return newWall;
}

// UfoObject* createUfo(void) {
//     UfoObject* newUfo = new UfoObject;

//     newUfo->destroyed = false;

//     newUfo->startTime = gameState.elapsedTime;
//     newUfo->currentTime = newUfo->startTime;

//     newUfo->size = UFO_SIZE;

//     newUfo->position = glm::vec3(0.0f, 0.0f, 0.1f);
//     // random speed in range 0.0f ... 1.0f
//     newUfo->speed = 0.0f;
//     // random rotation speed in range 0.0f ... 1.0f
//     newUfo->speed = 0.0f;

//     // generate randomly in range -1.0f ... 1.0f
//     newUfo->direction = glm::vec3(
//         0.0f,
//         1.0f,
//         0.0f
//     );
//     // newUfo->direction = glm::vec3(
//     //     0.0f,
//     //     (float)(2.0 * (rand() / (double)RAND_MAX) - 1.0),
//     //     0.0f
//     // );

//     newUfo->direction = glm::normalize(newUfo->direction);

//     return newUfo;
// }

const int mazeWidth = 8;
const int mazeHeight = 9;

int maze[mazeWidth][mazeHeight] = {
    {0, 1, 0, 0, 0, 0, 0, 0, 0},
    {0, 1, 1, 1, 1, 1, 1, 1, 0},
    {0, 0, 0, 1, 1, 0, 0, 1, 0},
    {0, 1, 0, 1, 0, 1, 0, 1, 1},
    {0, 1, 0, 1, 1, 1, 0, 0, 0},
    {1, 1, 1, 0, 0, 1, 1, 1, 0},
    {0, 1, 1, 1, 1, 1, 0, 1, 0},
    {0, 1, 0, 0, 0, 0, 0, 0, 0},
};

void restartGame(void) {

    cleanUpObjects();

    timer_countdown = false;
    countdown = GAME_TIME;

    fog_linear = false;
    fog_exp = false;
    fog_near = -0.7f;
    fog_density = 0.0f;
    fog_exp_flag = true;
    animate = 1;
    isMouseWarped = false;

    auto configValues = readConfig("config.ini");

    std::cout << "Fog Linear: " << (fog_linear ? "true" : "false") << std::endl;
    std::cout << "Fog Exponential: " << (fog_exp ? "true" : "false") << std::endl;
    std::cout << "Fog Near: " << fog_near << std::endl;
    std::cout << "Fog Density: " << fog_density << std::endl;

    gameState.elapsedTime = 0.001f * (float)glutGet(GLUT_ELAPSED_TIME); // milliseconds => seconds

    // initialize space ship
    if (gameObjects.shark == NULL)
        gameObjects.shark = new SharkObject;

    shark_startpoint = getRandomNumber();
    sharkstartpoint(shark_startpoint);

    gameObjects.shark->direction = glm::vec3(cos(glm::radians(gameObjects.shark->viewAngle)), sin(glm::radians(gameObjects.shark->viewAngle)), 0.0f);
    gameObjects.shark->size = configValues["Shark.size"];
    gameObjects.shark->startTime = gameState.elapsedTime;
    gameObjects.shark->currentTime = gameObjects.shark->startTime;
    gameObjects.shark->speed = configValues["Shark.speed"];

    if (gameObjects.terrain == NULL)
        gameObjects.terrain = new TerrainObject;

    gameObjects.terrain->position = glm::vec3(0.0f, 0.0f, -0.025f);
    gameObjects.terrain->size = TERRAIN_SIZE;

    if (gameObjects.mushroom == NULL)
        gameObjects.mushroom = new MushroomObject;

    gameObjects.mushroom->position = glm::vec3(-0.2f, -0.2f, 0.0f);
    gameObjects.mushroom->destroyed = false;
    gameObjects.mushroom->size = MUSHROOM_SIZE;

    if (gameObjects.santa == NULL)
        gameObjects.santa = new SantaObject;

    gameObjects.santa->startTime = gameState.elapsedTime;
    gameObjects.santa->currentTime = gameObjects.santa->startTime;
    gameObjects.santa->initPosition = glm::vec3(0.3f, 0.0f, 0.0f);
    gameObjects.santa->position = gameObjects.santa->initPosition;
    gameObjects.santa->destroyed = false;
    gameObjects.santa->size = configValues["Santa.size"];
    gameObjects.santa->speed = configValues["Santa.speed"];
    gameObjects.santa->direction = glm::vec3(0.0f, 0.0f, 0.0f);
    gameObjects.santa->direction = glm::normalize(gameObjects.santa->direction);


    if (gameObjects.yoshi == NULL)
        gameObjects.yoshi = new YoshiObject;

    gameObjects.yoshi->position = glm::vec3(-0.5f, -0.2f, 0.0f);
    gameObjects.yoshi->destroyed = false;
    gameObjects.yoshi->size = YOSHI_SIZE;

    if (gameObjects.snowman == NULL)
        gameObjects.snowman = new SnowmanObject;

    gameObjects.snowman->position = glm::vec3(-0.5f, -0.6f, 0.0f);
        gameObjects.snowman->destroyed = false;
    gameObjects.snowman->size = SNOWMAN_SIZE;

    if (gameObjects.gingerbreadman == NULL)
        gameObjects.gingerbreadman = new GingerbreadmanObject;

    gameObjects.gingerbreadman->position = glm::vec3(-0.3f, 0.4f, 0.0f);
    gameObjects.gingerbreadman->destroyed = false;
    gameObjects.gingerbreadman->size = GINGERBREADMAN_SIZE;

    if (gameObjects.chicken == NULL)
        gameObjects.chicken = new ChickenObject;

    gameObjects.chicken->position = glm::vec3(0.5f, -0.6f, 0.0f);
    gameObjects.chicken->destroyed = false;
    gameObjects.chicken->size = CHICKEN_SIZE;

    if (gameObjects.ditto == NULL)
        gameObjects.ditto = new DittoObject;

    gameObjects.ditto->position = glm::vec3(0.5f, 0.4f, 0.0f);
    gameObjects.ditto->startTime = gameState.elapsedTime;
    gameObjects.ditto->currentTime = gameState.elapsedTime;
    gameObjects.ditto->destroyed = false;
    gameObjects.ditto->size = DITTO_SIZE;

    if (gameObjects.plane == NULL)
        gameObjects.plane = new PlaneObject;

    gameObjects.plane->angle = 0.0f;
    gameObjects.plane->destroyed = false;
    gameObjects.plane->position = glm::vec3(0.5f * sin(gameObjects.plane->angle), 0.5f * cos(gameObjects.plane->angle), 0.5f);
    gameObjects.plane->size = configValues["Plane.size"];

    if (gameObjects.cone == NULL)
        gameObjects.cone = new ConeObject;

    gameObjects.cone->destroyed = false;
    gameObjects.cone->size = CONE_SIZE;
    gameObjects.cone->position = glm::vec3(-0.1f, 0.0f, 0.0f);
    gameObjects.cone->speed = 0.0f;
    gameObjects.cone->direction = glm::vec3(
        0.0f,
        1.0f,
        0.0f
    );
    gameObjects.cone->direction = glm::normalize(gameObjects.cone->direction);

    // initialize walls
    float Y = 1.0;
    float X = 0.9;
    for (int i = 0; i < 9; i++) {
        X = 0.9;
        Y -= 0.2;
        for (int j = 0; j < 8; j++) {
            X -= 0.2;
            if (maze[j][i] == 0) {
                WallObject* newWall = createWall(X, Y);

                gameObjects.walls.push_back(newWall);
            }
        }
    }

    // UfoObject* newUfo = createUfo();
    // gameObjects.ufos.push_back(newUfo);

        gameState.CameraMode = 3;
    gameState.cameraElevationAngle = 0.0f;

    // reset key map
    for (int i = 0; i < KEYS_COUNT; i++)
        gameState.keyMap[i] = false;

    gameState.gameOver = false;
    gameState.gameWon = false;


}

BannerObject* createBanner(void) {
    BannerObject* newBanner = new BannerObject;

    newBanner->size = BANNER_SIZE;
    newBanner->position = glm::vec3(0.0f, 0.0f, 0.0f);
    newBanner->direction = glm::vec3(0.0f, 1.0f, 0.0f);
    newBanner->speed = 0.0f;
    newBanner->size = 1.0f;

    newBanner->destroyed = false;

    newBanner->startTime = gameState.elapsedTime;
    newBanner->currentTime = newBanner->startTime;

    return newBanner;
}


void drawWindowContents() {

    // setup parallel projection
    glm::mat4 orthoProjectionMatrix = glm::ortho(
        -SCENE_WIDTH, SCENE_WIDTH,
        -SCENE_HEIGHT, SCENE_HEIGHT,
        -10.0f * SCENE_DEPTH, 10.0f * SCENE_DEPTH
    );
    // static viewpoint - top view
    glm::mat4 orthoViewMatrix = glm::lookAt(
        glm::vec3(0.0f, 0.0f, 1.0f),
        glm::vec3(0.0f, 0.0f, 0.0f),
        glm::vec3(0.0f, 1.0f, 0.0f)
    );

    // setup camera & projection transform
    glm::mat4 viewMatrix = orthoViewMatrix;
    glm::mat4 projectionMatrix = orthoProjectionMatrix;

    if (gameState.CameraMode == 2) {

        float left = -SCENE_WIDTH / 2.5f;
        float right = SCENE_WIDTH / 2.5f;
        float bottom = -SCENE_HEIGHT / 2.5f;
        float top = SCENE_HEIGHT / 2.5f;

        // Set the desired z-axis value (adjust as needed)
        float cameraHeight = 1.0f;

        // Use glm::vec3 to define the camera position
        glm::vec3 cameraCenter = gameObjects.shark->position;
        glm::vec3 cameraPosition = cameraCenter + glm::vec3(0.0f, 0.0f, cameraHeight);

        // Set up an orthographic projection matrix
        projectionMatrix = glm::ortho(left, right, bottom, top, 0.1f, 10.0f);

        // Set up the view matrix
        viewMatrix = glm::lookAt(
            cameraPosition,     // Camera position
            cameraCenter,       // Camera target (center)
            glm::vec3(0.0f, 1.0f, 0.0f)   // Up vector
        );
    }

    if (gameState.CameraMode == 1) { //move to cam direction

      // compute correctly camera position and up vector using space ship parameters
        glm::vec3 cameraPosition = gameObjects.shark->position;
        glm::vec3 cameraUpVector = glm::vec3(0.0f, 0.0f, 1.0f);

        glm::vec3 cameraViewDirection = gameObjects.shark->direction;

        // update camera view direction vector and cameraUpVector by gameState.cameraElevationAngle variable
        // b) using rotation matrix
        glm::vec3 rotationAxis = glm::cross(cameraViewDirection, cameraUpVector);
        glm::mat4 cameraTransform = glm::rotate(glm::mat4(1.0f), glm::radians(gameState.cameraElevationAngle), rotationAxis);

        cameraUpVector = glm::vec3(cameraTransform * glm::vec4(cameraUpVector, 0.0f));
        cameraViewDirection = glm::vec3(cameraTransform * glm::vec4(cameraViewDirection, 0.0f));

        glm::vec3 cameraCenter = cameraPosition + cameraViewDirection;

        //d::cout << "Camera Center: (" << cameraCenter.x << ", " << cameraCenter.y << ", " << cameraCenter.z << ")" << std::endl;

        viewMatrix = glm::lookAt(
            cameraPosition,
            cameraCenter,
            cameraUpVector
        );

        projectionMatrix = glm::perspective(glm::radians(fieldofview), gameState.windowWidth / (float)gameState.windowHeight, SHARK_SIZE, 10.0f);
    }
    if (sin(gameState.elapsedTime*0.5f)<0 & animate == 1){
        if (day_flag) {
            day = 1;
        }
    }
    if (sin(gameState.elapsedTime*0.5f)>=0){
        if (day_flag) {
            day = 0;
        }
    }
    glUseProgram(shaderProgram.program);
    //oricode
    glUniform1f(shaderProgram.timeLocation, gameState.elapsedTime);

    glUniform1f(shaderProgram.fogOnLoc_linear, fog_linear);
    glUniform1f(shaderProgram.fogOnLoc_near, fog_near);
    glUniform1f(shaderProgram.fogOnLoc_exp, fog_exp);
    glUniform1f(shaderProgram.fogOnLoc_density, fog_density);

    glUniform1i(shaderProgram.animateLoc, animate);
    glUniform1i(shaderProgram.pointLoc, point);

    glUniform3fv(shaderProgram.reflectorPositionLocation, 1, glm::value_ptr(gameObjects.shark->position - 0.07f * gameObjects.shark->direction));
    glUniform3fv(shaderProgram.reflectorDirectionLocation, 1, glm::value_ptr(gameObjects.shark->direction));
    glUseProgram(0);

    // draw space ship
    drawShark(gameObjects.shark, viewMatrix, projectionMatrix);

    CHECK_GL_ERROR();
    // draw walls
    for (GameObjectsList::iterator it = gameObjects.walls.begin(); it != gameObjects.walls.end(); ++it) {
        CHECK_GL_ERROR();

        WallObject* wall = (WallObject*)(*it);
        drawWall(wall, viewMatrix, projectionMatrix);
    }

    // Draw the obj
    // for (GameObjectsList::iterator it = gameObjects.ufos.begin(); it != gameObjects.ufos.end(); ++it) {
    //     UfoObject* ufo = (UfoObject*)(*it);
    //     drawUfo(ufo, viewMatrix, projectionMatrix);
    // }

    // creating id for obj 
    // Enable stencil test

    glEnable(GL_STENCIL_TEST);

    // Set the stencil operations
    glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);

    // Set the stencil test function
    glStencilFunc(GL_ALWAYS, 1, 0xFF);  // Set the stencil reference to 1 -> mushroom id = 1

    // Draw the obj
    drawMushroom(gameObjects.mushroom, viewMatrix, projectionMatrix);

    // Disable stencil test after drawing objects
    glDisable(GL_STENCIL_TEST);

    glEnable(GL_STENCIL_TEST);

    // Set the stencil operations
    glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);

    // Set the stencil test function
    glStencilFunc(GL_ALWAYS, 2, 0xFF);  // Set the stencil reference to 2 -> terrain id = 1

    // Draw the obj
    drawGingerbreadman(gameObjects.gingerbreadman, viewMatrix, projectionMatrix);

    // Disable stencil test after drawing objects
    glDisable(GL_STENCIL_TEST);

    // Enable stencil test
    glEnable(GL_STENCIL_TEST);

    // Set the stencil operations
    glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);

    // Set the stencil test function
    glStencilFunc(GL_ALWAYS, 3, 0xFF);  // Set the stencil reference to 3 -> mushroom id = 1

    // Draw the obj
    drawSanta(gameObjects.santa, viewMatrix, projectionMatrix);

    // Disable stencil test after drawing objects
    glDisable(GL_STENCIL_TEST);

    glEnable(GL_STENCIL_TEST);

    // Set the stencil operations
    glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);

    // Set the stencil test function
    glStencilFunc(GL_ALWAYS, 4, 0xFF);  // Set the stencil reference to 4 -> terrain id = 1

    // Draw the obj
    drawYoshi(gameObjects.yoshi, viewMatrix, projectionMatrix);

    // Disable stencil test after drawing objects
    glDisable(GL_STENCIL_TEST);

    glEnable(GL_STENCIL_TEST);

    // Set the stencil operations
    glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);

    // Set the stencil test function
    glStencilFunc(GL_ALWAYS, 5, 0xFF);  // Set the stencil reference to 5 

    // Draw the obj
    drawSnowman(gameObjects.snowman, viewMatrix, projectionMatrix);

    // Disable stencil test after drawing objects
    glDisable(GL_STENCIL_TEST);

    glEnable(GL_STENCIL_TEST);

    // Set the stencil operations
    glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);

    // Set the stencil test function
    glStencilFunc(GL_ALWAYS, 6, 0xFF);  // Set the stencil reference to 6 

    // Draw the obj
    drawChicken(gameObjects.chicken, viewMatrix, projectionMatrix);

    // Disable stencil test after drawing objects
    glDisable(GL_STENCIL_TEST);

    glEnable(GL_STENCIL_TEST);

    // Set the stencil operations
    glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);

    // Set the stencil test function
    glStencilFunc(GL_ALWAYS, 7, 0xFF);  // Set the stencil reference to 7 

    // Draw the obj
    drawDitto(gameObjects.ditto, viewMatrix, projectionMatrix);

    // Disable stencil test after drawing objects
    glDisable(GL_STENCIL_TEST);

    glEnable(GL_STENCIL_TEST);

    // Set the stencil operations
    glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);

    // Set the stencil test function
    glStencilFunc(GL_ALWAYS, 8, 0xFF);  // Set the stencil reference to 8 

    // Draw the obj
    drawPlane(gameObjects.plane, viewMatrix, projectionMatrix);

    // Disable stencil test after drawing objects
    glDisable(GL_STENCIL_TEST);

    glEnable(GL_STENCIL_TEST);

    // Set the stencil operations
    glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);

    // Set the stencil test function
    glStencilFunc(GL_ALWAYS, 9, 0xFF);  // Set the stencil reference to 9 

    drawCone(gameObjects.cone, viewMatrix, projectionMatrix);

    // Disable stencil test after drawing objects
    glDisable(GL_STENCIL_TEST);

    glEnable(GL_STENCIL_TEST);

    // Set the stencil operations
    glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);

    // Set the stencil test function
    glStencilFunc(GL_ALWAYS, 11, 0xFF);  // Set the stencil reference to 11 

    // Draw the obj
    drawTerrain(gameObjects.terrain, viewMatrix, projectionMatrix);

    // Disable stencil test after drawing objects
    glDisable(GL_STENCIL_TEST);


    glEnable(GL_STENCIL_TEST);
    glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);
    CHECK_GL_ERROR();

    // draw skybox
    drawSkybox(viewMatrix, projectionMatrix, day);

    // draw explosions with depth test disabled
    glDisable(GL_DEPTH_TEST);

    for(GameObjectsList::iterator it = gameObjects.explosions.begin(); it != gameObjects.explosions.end(); ++it) {
        ExplosionObject* explosion = (ExplosionObject *)(*it);
        drawExplosion(explosion, viewMatrix, projectionMatrix); 
    }
  glEnable(GL_DEPTH_TEST);

    if (gameState.gameOver == true) {
        // draw game over banner
        if (gameObjects.bannerObject != NULL)
           // std::cout << "gameover" << std::endl;
            drawBanner(gameObjects.bannerObject, orthoViewMatrix, orthoProjectionMatrix, false);
    }

    if (gameState.gameWon == true) {
        // draw game won banner
        if (gameObjects.bannerObject != NULL)
            //std::cout << "won" << std::endl;
            drawBanner(gameObjects.bannerObject, orthoViewMatrix, orthoProjectionMatrix, true);
    }
    
}

// Called to update the display. You should call glutSwapBuffers after all of your
// rendering to display what you rendered.
void displayCallback() {
    GLbitfield mask = GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT;

    glClear(mask);

    drawWindowContents();

    glutSwapBuffers();
}

// Called whenever the window is resized. The new window size is given, in pixels.
// This is an opportunity to call glViewport or glScissor to keep up with the change in size.
void reshapeCallback(int newWidth, int newHeight) {

    gameState.windowWidth = newWidth;
    gameState.windowHeight = newHeight;

    glViewport(0, 0, (GLsizei)newWidth, (GLsizei)newHeight);
}

void updateObjects(float elapsedTime) {

    // update space ship 
    float timeDelta = elapsedTime - gameObjects.shark->currentTime;
    gameObjects.shark->currentTime = elapsedTime;

    // // update ufos
    // GameObjectsList::iterator it;
    // it = gameObjects.ufos.begin();
    // while (it != gameObjects.ufos.end()) {
    //     UfoObject* ufo = (UfoObject*)(*it);

    //     if (ufo->destroyed == true) {
    //         it = gameObjects.ufos.erase(it);
    //     }
    //     else {
    //         // update ufo
    //         ufo->currentTime = elapsedTime;

    //         ++it;
    //     }
    // }

        if (gameObjects.cone->destroyed == true) {
            gameObjects.cone->size = 0.0f;
        }

        if (gameObjects.ditto->destroyed == true) {
            gameObjects.ditto->size = 0.0f;
        }
        if (gameObjects.plane->destroyed == true) {
            gameObjects.plane->size = 0.0f;
        }
        if (gameObjects.santa->destroyed == true) {
            gameObjects.santa->size = 0.0f;
        }
        if (gameObjects.snowman->destroyed == true) {
            gameObjects.snowman->size = 0.0f;
        }
        if (gameObjects.chicken->destroyed == true) {
            gameObjects.chicken->size = 0.0f;
        }
        if (gameObjects.gingerbreadman->destroyed == true) {
            gameObjects.gingerbreadman->size = 0.0f;
        }
        if (gameObjects.mushroom->destroyed == true) {
            gameObjects.mushroom->size = 0.0f;
        }
        if (gameObjects.yoshi->destroyed == true) {
            gameObjects.yoshi->size = 0.0f;
        }

        else {
            float timeDelta = elapsedTime - gameObjects.shark->currentTime;

            if (moving) {
                gameObjects.santa->currentTime = elapsedTime;

            }
            float curveParamT = gameObjects.santa->speed * (gameObjects.santa->currentTime - gameObjects.santa->startTime);

            gameObjects.santa->position = gameObjects.santa->initPosition + evaluateClosedCurve(curveData, curveSize, curveParamT);
            gameObjects.santa->direction = glm::normalize(evaluateClosedCurve_1stDerivative(curveData, curveSize, curveParamT));

            // check the new position and wrap it if it is necessary
            gameObjects.santa->position = checkBounds(gameObjects.santa->position, gameObjects.santa->size);
         

    }
       
    // update explosion billboards
        GameObjectsList::iterator it;
    it = gameObjects.explosions.begin();
    while(it != gameObjects.explosions.end()) {
        ExplosionObject* explosion = (ExplosionObject*)(*it);

        // update explosion
        explosion->currentTime = elapsedTime;

        if(explosion->currentTime > explosion->startTime + explosion->textureFrames*explosion->frameDuration)
            explosion->destroyed = true;

        if(explosion->destroyed == true) {
            it = gameObjects.explosions.erase(it);
        }
        else {
            ++it;
        }
    }

}

// Callback responsible for the scene update
void timerCallback(int) {

    // update scene time
    gameState.elapsedTime = 0.001f * (float)glutGet(GLUT_ELAPSED_TIME); // milliseconds => seconds

    if (gameState.keyMap[KEY_RIGHT_ARROW] == true) //increase field of view
        if (fieldofview <= 80.0) {
            fieldofview += 1;
        }

    if (gameState.keyMap[KEY_LEFT_ARROW] == true) //decrease field of view
        if (fieldofview >= 40.0) {
            fieldofview -= 1;
        }

    if (fog_linear == true) {
        if (gameState.keyMap[KEY_UP_ARROW] == true) //increase fog
            if (fog_near <= 0.0) {
                fog_near += 0.1;
            }

        if (gameState.keyMap[KEY_DOWN_ARROW] == true) // decrease fog
            if (fog_near >= -2.0) {
                fog_near -= 0.1;
            }
    }

    if (fog_exp == true) {
        if (gameState.keyMap[KEY_UP_ARROW] == true) //increase fog
            if (fog_density <= 20.0){
                fog_density += 0.1;
            }

        if (gameState.keyMap[KEY_DOWN_ARROW] == true) // decrease fog
            if (fog_density >= 0.0) {
                fog_density -= 0.1;
            }
    }

    if (animate == 1 & countdown & fog_exp_flag) {
        fog_exp = true;
        if (fog_density <= 20.0) {
            fog_density += 0.005;
        }
    }

    if (gameState.keyMap[W] == true)
        moveSharkForward();

    if (gameState.keyMap[S] == true)
        moveSharkBackward();

    if (gameState.keyMap[A] == true)
        turnSharkLeft(SHARK_VIEW_ANGLE_DELTA);

    if (gameState.keyMap[D] == true)
        turnSharkRight(SHARK_VIEW_ANGLE_DELTA);

    if (gameState.keyMap[U] & gameState.CameraMode==1) {

        isMouseWarped = false;
    }


    if (gameObjects.chicken->destroyed && gameObjects.ditto->destroyed && gameObjects.santa->destroyed
        && gameObjects.mushroom->destroyed && gameObjects.yoshi->destroyed && gameObjects.plane->destroyed
        && gameObjects.gingerbreadman->destroyed && gameObjects.snowman->destroyed){
            gameState.gameWon = true;
            timer_countdown = false;
        }
    
    if ((gameState.gameOver == true) && (gameObjects.bannerObject != NULL)) {
        gameObjects.bannerObject->currentTime = gameState.elapsedTime;
    }
    if ((gameState.gameWon == true) && (gameObjects.bannerObject != NULL)) {
        gameObjects.bannerObject->currentTime = gameState.elapsedTime;
    }

    if (moving){
        gameObjects.plane->angle = fmod((gameObjects.plane->angle + 0.1f) , 360.0f);
        float rad_angle = glm::radians(gameObjects.plane->angle);
        gameObjects.plane->position = glm::vec3(0.5f * sin(rad_angle), 0.5f * cos(rad_angle), 0.5f);
     
    }

    // update objects in the scene
    updateObjects(gameState.elapsedTime);

    // game over? -> create banner with scrolling text "game over"
    if (gameState.gameOver == true) {
        //gameState.keyMap[KEY_SPACE] = false; //whats this?
        if (gameObjects.bannerObject == NULL) {
            // if game over and banner still not created -> create banner
            gameObjects.bannerObject = createBanner();
        }
    }

    //if win 
    if (gameState.gameWon == true) {
        //gameState.keyMap[KEY_SPACE] = false; //whats this?
        if (gameObjects.bannerObject == NULL) {
            // if game over and banner still not created -> create banner
            gameObjects.bannerObject = createBanner();
        }
    }

    // generate new ufos randomly
    // if (gameObjects.ufos.size() < UFOS_COUNT_MIN) {
    //     int howManyUfos = rand() % (UFOS_COUNT_MAX - UFOS_COUNT_MIN + 1);

    //     for (int i = 0; i < howManyUfos; i++) {
    //         UfoObject* newUfo = createUfo();

    //         gameObjects.ufos.push_back(newUfo);
    //     }
    // }

    // set timeCallback next invocation
    glutTimerFunc(33, timerCallback, 0);

    glutPostRedisplay();
}

void timerCountdown(int value) {
    if (countdown > 0 & timer_countdown) {
        std::cout << "Countdown: " << countdown << " seconds remaining." << std::endl;
        countdown--;

        // Register the timer callback again after 1000 milliseconds (1 second)
        glutTimerFunc(1000, timerCountdown, 0);
    }
    if(countdown <=0 & timer_countdown){
        std::cout << "Countdown finished!" << std::endl;
        gameState.gameOver = true;
        gameState.gameWon = false;
        timer_countdown = false;
    }
}

// Called when mouse is moving while no mouse buttons are pressed.
void handleMouse(int mouseX, int mouseY) {

    std::cout << "mousewarp" << isMouseWarped << std::endl;
    if (isMouseWarped) {
        std::cout << "warpeddddd" << std::endl;
        if (mouseY != gameState.windowHeight / 2) {
            float cameraElevationAngleDelta = 0.5f * (mouseY - gameState.windowHeight / 2);

            if (fabs(gameState.cameraElevationAngle + cameraElevationAngleDelta) < CAMERA_ELEVATION_MAX)
                gameState.cameraElevationAngle += cameraElevationAngleDelta;

            // Disable mouse warping temporarily to prevent glutWarpPointer from triggering this callback.
            //isMouseWarped = false;

            // Set mouse pointer to the window center.
            glutWarpPointer(gameState.windowWidth / 2, gameState.windowHeight / 2);

            // Re-enable mouse warping.
            //isMouseWarped = true;
        }
    }
    glutPostRedisplay();

}

void mouseCallback(int buttonPressed, int buttonState, int mouseX, int mouseY) {

    if ((buttonPressed == GLUT_LEFT_BUTTON) && (buttonState == GLUT_DOWN)) {
        mouseY = (WINDOW_HEIGHT - 1) - mouseY;
        unsigned char ID = 0;

        (mouseX, mouseY, 1, 1, GL_STENCIL_INDEX, GL_UNSIGNED_BYTE, &ID);
        glReadPixels(mouseX, mouseY, 1, 1, GL_STENCIL_INDEX, GL_UNSIGNED_BYTE, &ID);
        // if (ID == 0) {
        //   std::cout << "you pressed backgroud\n";
        // }
        // else {
        //   //game.pickObject = ID;
        //   std::cout << "Picked Object with ID: " << (int)ID <<std::endl;

        // }
        switch (ID) {
        case 1:
            //mushroom
            gameObjects.mushroom->destroyed = true;
            insertExplosion(gameObjects.mushroom->position, gameObjects.mushroom->size);
            std::cout << "Picked mushroom with ID: " << 1 << std::endl;
            break;
        case 2:
            //gingerbreadman
            gameObjects.gingerbreadman->destroyed = true;
            insertExplosion(gameObjects.gingerbreadman->position, gameObjects.gingerbreadman->size);
            std::cout << "Picked gingerbreadman with ID: " << 2 << std::endl;
            break;
        case 3:
            //santa
            gameObjects.santa->destroyed = true;
            insertExplosion(gameObjects.santa->position, gameObjects.santa->size);
            std::cout << "Picked santa with ID: " << 3 << std::endl;
            break;
        case 4:
            //yoshi
            gameObjects.yoshi->destroyed = true;
            insertExplosion(gameObjects.yoshi->position, gameObjects.yoshi->size);
            std::cout << "Picked yoshi with ID: " << 4 << std::endl;
            break;
        case 5:
            //snowman
            gameObjects.snowman->destroyed = true;
            insertExplosion(gameObjects.snowman->position, gameObjects.snowman->size);
            std::cout << "Picked snowman with ID: " << 5 << std::endl;
            break;
        case 6:
            //chicken
            gameObjects.chicken->destroyed = true;
            insertExplosion(gameObjects.chicken->position, gameObjects.chicken->size);
            std::cout << "Picked chicken with ID: " << 6 << std::endl;
            break;
        case 7:
            //ditto
            gameObjects.ditto->destroyed = true;
            insertExplosion(gameObjects.ditto->position, gameObjects.ditto->size);
            std::cout << "Picked ditto with ID: " << 7 << std::endl;
            break;
        case 8:
            //plane
            gameObjects.plane->destroyed = true;
            insertExplosion(gameObjects.plane->position, gameObjects.plane->size);
            std::cout << "Picked plane with ID: " << 8 << std::endl;
            break;

        case 9:
            //cone
            gameObjects.cone->destroyed = true;
            insertExplosion(gameObjects.cone->position, gameObjects.cone->size);
            std::cout << "Picked plane with ID: " << 9 << std::endl;
            break;


        default:
            break;
        }
        std::cout << "Picked Object with ID: " << (int)ID << std::endl;


    }

}

// Called whenever a key on the keyboard was pressed. The key is given by the "keyPressed"
// parameter, which is in ASCII. It's often a good idea to have the escape key (ASCII value 27)

void keyboardCallback(unsigned char keyPressed, int mouseX, int mouseY) {

    switch (keyPressed) {
    case 27: // escape
#ifndef __APPLE__
        glutLeaveMainLoop(); //exit program
#else
        exit(0);
#endif
        break;
    case 'r': // restart game
        restartGame();
        break;

    case '1': // switch camera
        gameState.CameraMode = 1; //pov 
        isMouseWarped = true;
        std::cout << isMouseWarped << std::endl;
        break;

    case '2': // switch camera
        gameState.CameraMode = 2; //birds eye view following shark
        isMouseWarped = false;
        break;

    case '3': // switch camera
        gameState.CameraMode = 3; //whole scene
        isMouseWarped = false;
        break;

    case 'w': // move up
        gameState.keyMap[W] = true;
        break;

    case 's': // move up
        gameState.keyMap[S] = true;
        break;

    case 'a': // move up
        gameState.keyMap[A] = true;
        break;

    case 'd': // move up
        gameState.keyMap[D] = true;
        break;

    case'e': { // insert explosion randomly
        glm::vec3 explosionPosition = glm::vec3(
            (float)(2.0 * (rand() / (double)RAND_MAX) - 1.0),
            (float)(2.0 * (rand() / (double)RAND_MAX) - 1.0),
            0.0f
        );
        insertExplosion(explosionPosition, BILLBOARD_SIZE);
    }
           break;

    case 'u': // unlock
        gameState.keyMap[U] = true;
        break;

    case 'c': {
        std::cout << "Reloading config file" << std::endl;
        gameState.keyMap[C] = true;
        reloadConfig();
        break;
    }

    default:
        ; // printf("Unrecognized key pressed\n");
    }

    if ((gameState.keyMap[W] || gameState.keyMap[S] || gameState.keyMap[A] || gameState.keyMap[D]) & (timer_countdown==false)){
        timer_countdown = true;
        printf("timecountdown is true");
        glutTimerFunc(1000, timerCountdown, 0);
    }

}

// Called whenever a key on the keyboard was released. The key is given by
// the "keyReleased" parameter, which is in ASCII. 
void keyboardUpCallback(unsigned char keyReleased, int mouseX, int mouseY) {

    switch (keyReleased) {
    //case ' ':
        //gameState.keyMap[KEY_SPACE] = false;
        //break;

    case 'w': // move up
        gameState.keyMap[W] = false;
        break;

    case 's': // move up
        gameState.keyMap[S] = false;
        break;

    case 'a': // move up
        gameState.keyMap[A] = false;
        break;

    case 'd': // move up
        gameState.keyMap[D] = false;
        break;

    case 'u': // move up
        gameState.keyMap[U] = false;
        if (gameState.CameraMode == 1) {
            isMouseWarped = true;
        }
            break;
    case 'c': {
        gameState.keyMap[C] = false;
        break;
    }

    default:
        ; // printf("Unrecognized key released\n");
    }
 
        
}

// The special keyboard callback is triggered when keyboard function or directional
// keys are pressed.
void specialKeyboardCallback(int specKeyPressed, int mouseX, int mouseY) {

    if (gameState.gameOver == true)
        return;

    if (gameState.gameWon == true)
        return;

    switch (specKeyPressed) {
    case GLUT_KEY_RIGHT:
        gameState.keyMap[KEY_RIGHT_ARROW] = true;
        break;
    case GLUT_KEY_LEFT:
        gameState.keyMap[KEY_LEFT_ARROW] = true;
        break;
    case GLUT_KEY_UP:
        gameState.keyMap[KEY_UP_ARROW] = true;
        break;
    case GLUT_KEY_DOWN:
        gameState.keyMap[KEY_DOWN_ARROW] = true;
        break;
    default:
        ; // printf("Unrecognized special key pressed\n");
    }
}

// The special keyboard callback is triggered when keyboard function or directional
// keys are released.
void specialKeyboardUpCallback(int specKeyReleased, int mouseX, int mouseY) {

    if (gameState.gameOver == true)
        return;
    if (gameState.gameWon == true)
        return;

    switch (specKeyReleased) {
    case GLUT_KEY_RIGHT:
        gameState.keyMap[KEY_RIGHT_ARROW] = false;
        break;
    case GLUT_KEY_LEFT:
        gameState.keyMap[KEY_LEFT_ARROW] = false;
        break;
    case GLUT_KEY_UP:
        gameState.keyMap[KEY_UP_ARROW] = false;
        break;
    case GLUT_KEY_DOWN:
        gameState.keyMap[KEY_DOWN_ARROW] = false;
        break;
    default:
        ; // printf("Unrecognized special key released\n");
    }
}

// Called after the window and OpenGL are initialized. Called exactly once, before the main loop.
void initializeApplication() {

    // initialize random seed
    srand((unsigned int)time(NULL));

    // initialize OpenGL
    glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
    glEnable(GL_DEPTH_TEST);

    useLighting = true;

    // initialize shaders
    initializeShaderPrograms();
    // create geometry for all models used
    initializeModels();

    gameObjects.shark = NULL;
    gameObjects.bannerObject = NULL;

    restartGame();
}

void finalizeApplication(void) {

    cleanUpObjects();

    delete gameObjects.shark;
    gameObjects.shark = NULL;

    // delete buffers - space ship, walls, missile, ufo, banner, and explosion
    cleanupModels();

    // delete shaders
    cleanupShaderPrograms();
}

// void menuPoint(int menuItemID) {

void menuCamera(int menuItemID) {

    switch (menuItemID) {
    case 1:
        gameState.CameraMode = 1;
        break;
    case 2:
        gameState.CameraMode = 2;
        break;
    case 3:
        gameState.CameraMode = 3;
        break;
    }
    glutPostRedisplay();
}

void menuFog(int menuItemID) {

    switch (menuItemID) {
    case 1:
        //fog linear on
        fog_linear = true;
        fog_exp = false;
        fog_exp_flag = false;
        break;
    case 2:
        //fog exp on
        fog_linear = false;
        fog_exp = true;
        break;
    case 3:
        //fog off
        fog_linear = false;
        fog_exp = false;
        fog_exp_flag = false;
        break;
    }
    glutPostRedisplay();
}

void menuTime(int menuItemID) { //changes sky box

    switch (menuItemID) {
    case 0:
        day = 0; //day time
        day_flag = false;
        break;
    case 1:
        day = 1; //night time
        day_flag = false;
        break;
    case 2:
        day = 1; //day + night time
        day_flag = true;
        break;
    }
    glutPostRedisplay();
}

void menuMove(int menuItemID) { //movement of plane

    switch (menuItemID) {
    case 0:
        moving = true;
        break;
    case 1:
        moving = false;
        break;
    }
    glutPostRedisplay();
}

void menuAnimate(int menuItemID) { //movement of plane

    switch (menuItemID) {
    case 0:
        animate = 1;
        moving = true;
        day_flag = true;
        
        break;
    case 1:
        animate = 0;
        moving = false;
        day = 0;
        
        break;
    }
    glutPostRedisplay();
}

void menuLight(int menuItemID) { //movement of plane

    switch (menuItemID) {
    case 0:
        point = 1;
        std::cout << "on" << std::endl;
        break;
    case 1:
        point = 0;
        std::cout << "off" << std::endl;
        break;
    }
    glutPostRedisplay();
}

void myMenu(int menuItemID) {

    switch (menuItemID) {
       
    case 0:
        gameState.gameOver = true;
        break;
    case 1:
        exit(0);
        break;
    case 2:
        restartGame();
        break;
    }
}


int main(int argc, char** argv) {

    // initialize windowing system
    glutInit(&argc, argv);

#ifndef __APPLE__
    glutInitContextVersion(pgr::OGL_VER_MAJOR, pgr::OGL_VER_MINOR);
    glutInitContextFlags(GLUT_FORWARD_COMPATIBLE);

    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH | GLUT_STENCIL);
#else
    glutInitDisplayMode(GLUT_3_2_CORE_PROFILE | GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH | GLUT_STENCIL);
#endif

    // initial window size
    glutInitWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);
    glutCreateWindow(WINDOW_TITLE);

    glutDisplayFunc(displayCallback);

    // register callback for change of window size
    glutReshapeFunc(reshapeCallback);

    //register callbacks for mouse
    glutMouseFunc(mouseCallback);
    glutPassiveMotionFunc(handleMouse);

    // register callbacks for keyboard
    glutKeyboardFunc(keyboardCallback);
    glutKeyboardUpFunc(keyboardUpCallback);
    glutSpecialFunc(specialKeyboardCallback);     // key pressed
    glutSpecialUpFunc(specialKeyboardUpCallback); // key released


    glutTimerFunc(33, timerCallback, 0);

    // initialize PGR framework (GL, DevIl, etc.)
    if (!pgr::initialize(pgr::OGL_VER_MAJOR, pgr::OGL_VER_MINOR))
        pgr::dieWithError("pgr init failed, required OpenGL not supported?");

    /* Create menu camera. */
    int idCamera = glutCreateMenu(menuCamera);
    glutAddMenuEntry("Camera 1 (POV)", 1);
    glutAddMenuEntry("Camera 2 (top view of shark)", 2);
    glutAddMenuEntry("Camera 3 (whole view)", 3);

    /* Create menu fog */
    int idFog = glutCreateMenu(menuFog);
    glutAddMenuEntry("Fog linear on", 1);
    glutAddMenuEntry("Fog exp on", 2);
    glutAddMenuEntry("Fog off", 3);

    /* Create menu plane movement */
    int idMove = glutCreateMenu(menuMove);
    glutAddMenuEntry("Plane move", 0);
    glutAddMenuEntry("Stop moving", 1);

    int idTime = glutCreateMenu(menuTime);
    glutAddMenuEntry("Day", 0);
    glutAddMenuEntry("Night", 1);
    glutAddMenuEntry("Day + Night", 2);

    int idAnimate = glutCreateMenu(menuAnimate);
    glutAddMenuEntry("animate", 0);
    glutAddMenuEntry("off animation", 1);

    int idLight = glutCreateMenu(menuLight);
    glutAddMenuEntry("on point light", 0);
    glutAddMenuEntry("off point light", 1);

    /*Create main menu*/
    glutCreateMenu(myMenu);
    glutAddSubMenu("Camera", idCamera);
    glutAddSubMenu("Fog", idFog);
    // glutAddSubMenu("Pointlight", idPoint);
    glutAddSubMenu("Animate", idAnimate);
    glutAddSubMenu("Point light", idLight);
    glutAddSubMenu("Time of the day", idTime);
    glutAddSubMenu("Plane movement", idMove);
    glutAddMenuEntry("GameOver", 0);
    glutAddMenuEntry("Quit", 1);
    glutAddMenuEntry("Restart", 2);

    /* Menu will be invoked by the right button click. */
    glutAttachMenu(GLUT_RIGHT_BUTTON);


    initializeApplication();

#ifndef __APPLE__
    glutCloseFunc(finalizeApplication);
#else
    glutWMCloseFunc(finalizeApplication);
#endif

    glutMainLoop();

    return 0;
}
